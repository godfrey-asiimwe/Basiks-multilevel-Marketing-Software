<?php 

define('APPS_CRAFT_RECIPIENT_EMAIL_ADDRESS', 'example@youremail.com');
define('APPS_CRAFT_MAIL_SUBJECT', 'New Contact Email.');
define('APPS_CRAFT_SUCCESS_MESSAGE', 'Successfully sent email.');